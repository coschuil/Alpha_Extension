﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeTask_Extension
{
   public static  class Extension
    {
        public static String Alpha(this double n)
        {
            string[] Teklikler = new string[] { "bir", "iki", "uc", "dord", "bes", "alti", "yeddi", "sekkiz", "doqquz", "on", "on bir", "on iki", "on uc", "on dord", "on bes", "on alti", "on yeddi", "on sekkiz", "on doqquz" };
            string[] Onluqlar = new string[] { "iyirmi", "otuz", "qirx", "elli", "altmis", "yetmis", "seksen", "doxsan" };
            string[] Minlikler = new string[] { "min", "million", "milyard", "trillion" };
            string soz = "";

            bool tens = false;

            if (n < 0)
            {
                soz += "Menfi ";
                n *= -1;
            }

            int power = (Minlikler.Length + 1) * 3;//15

            while (power > 3)
            {
                double pow = Math.Pow(10, power);
                if (n >= pow)//2 000 000 
                {
                    if (n % pow > 0)//=2 000 005/10^15=
                    {
                        soz += Alpha(Math.Floor(n / pow)) + " " + Minlikler[(power / 3) - 1] + ", ";
                    }
                    else if (n % pow == 0)
                    {
                        soz += Alpha(Math.Floor(n / pow)) + " " + Minlikler[(power / 3) - 1];
                    }
                    n %= pow;//5
                }
                power -= 3;
            }
            if (n >= 1000)
            {
                if (n % 1000 > 0) soz += Alpha(Math.Floor(n / 1000)) + " Min ";
                //else soz += Numsoz(Math.Floor(n / 1000)) + " Min";
                n %= 1000;
            }
            if (0 <= n && n <= 999)
            {
                if ((int)n / 100 > 0)
                {
                    soz += Alpha(Math.Floor(n / 100)) + " yuz";
                    n %= 100;
                }
                if ((int)n / 10 > 1)
                {
                    if (soz != "")
                        soz += " ";
                    soz += Onluqlar[(int)n / 10 - 2];
                    tens = true;
                    n %= 10;
                }

                if (n < 20 && n > 0)
                {
                    if (soz != "" && tens == false)
                        soz += " ";
                    soz += (tens ? " " + Teklikler[(int)n - 1] : Teklikler[(int)n - 1]);
                    n -= Math.Floor(n);
                }
            }

            return soz;
        }
        }
}
