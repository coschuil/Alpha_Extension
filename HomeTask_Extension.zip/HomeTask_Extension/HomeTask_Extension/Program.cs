﻿using System;
using System.Collections.Generic;
using System.Text;
using HomeTask_Extension;

namespace Numsoz
{
    class Program
    {
        static String NumsozWrapper(double n)
        {
            string soz = "";
            double TamHisse;
            double KesrHisse = 0;
            if (n == 0)
                return "zero";
            try
            {
                string[] splitter = n.ToString().Split('.');
                TamHisse = double.Parse(splitter[0]);
                KesrHisse = double.Parse(splitter[1]);
            }
            catch
            {
                TamHisse = n;
            }

            soz = Extension.Alpha(TamHisse);
            return soz;
        }
        static void Main(string[] args)
        {

            Console.Write("Enter a number to convert to soz: ");
            Double n = Double.Parse(Console.ReadLine());
            Console.WriteLine(NumsozWrapper(n));
            //Console.WriteLine(n.Alpha());
        }
    }
}